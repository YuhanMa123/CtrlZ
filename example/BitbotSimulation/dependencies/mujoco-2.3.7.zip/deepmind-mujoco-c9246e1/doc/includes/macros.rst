..
   Macros for adding non-breaking spaces for indentation.

.. |_| unicode:: 0xA0 0xA0
   :trim:

.. |_2| unicode:: 0xA0 0xA0 0xA0 0xA0
   :trim:

.. |_3| unicode:: 0xA0 0xA0 0xA0 0xA0 0xA0 0xA0
   :trim:

.. |_4| unicode:: 0xA0 0xA0 0xA0 0xA0 0xA0 0xA0 0xA0 0xA0
   :trim:

..
   Macro for L shaped arrow

.. |L| unicode:: 0x21B3  0xA0
   :trim:

..
   Macro for injecting a custom line break.

.. |br| raw:: html

  <br/>

..
   Macro for unicode word-joiner character.

.. |-| unicode:: U+2060
   :trim:
